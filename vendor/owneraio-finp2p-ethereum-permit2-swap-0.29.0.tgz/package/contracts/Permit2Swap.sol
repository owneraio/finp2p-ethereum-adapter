// SPDX-License-Identifier: Apache-2.0

pragma solidity ^0.8.20;

import {IAllowanceTransfer} from "./interfaces/IAllowanceTransfer.sol";

/**
 * @dev Standalone atomic swap between two ERC20 legs, moved through Uniswap
 * Permit2 (AllowanceTransfer).
 *
 * Setup per party and token: one standard ERC20 approve to Permit2, then a
 * Permit2 allowance naming THIS contract as spender (a signed PermitSingle
 * submitted to Permit2.permit by anyone). Amount and expiry bound the spend.
 * executeSwap crosses both legs in one transaction, once per operationId.
 *
 * Known risk: any caller can settle while both Permit2 allowances are live,
 * and an allowance does not bind the counter leg, so a caller may pick a
 * smaller counterAmount. A witness order (SignatureTransfer) closes this.
 */
contract Permit2Swap {
    struct Leg {
        address token;
        address party;
        uint256 amount;
        address counterToken;
        address counterParty;
        uint256 counterAmount;
    }

    /// @notice Both legs crossed atomically through Permit2
    event SwapExecuted(string indexed operationId, Leg leg);

    IAllowanceTransfer public immutable permit2;

    /// @notice operationIds already settled (replay guard)
    mapping(string => bool) public executed;

    constructor(address permit2_) {
        require(permit2_ != address(0), "Permit2Swap: permit2 is zero address");
        permit2 = IAllowanceTransfer(permit2_);
    }

    /// @notice Settle both legs in one call. Reverts, moving nothing, if either
    /// Permit2 allowance is missing, expired or too small.
    function executeSwap(string calldata operationId, Leg calldata leg) external {
        require(leg.token != address(0) && leg.counterToken != address(0), "Permit2Swap: token is zero address");
        require(leg.party != address(0) && leg.counterParty != address(0), "Permit2Swap: party is zero address");
        require(leg.amount > 0 && leg.counterAmount > 0, "Permit2Swap: amount is zero");
        require(
            leg.amount <= type(uint160).max && leg.counterAmount <= type(uint160).max,
            "Permit2Swap: amount exceeds uint160"
        );
        require(!executed[operationId], "Permit2Swap: swap already executed");

        executed[operationId] = true;
        permit2.transferFrom(leg.party, leg.counterParty, uint160(leg.amount), leg.token);
        permit2.transferFrom(leg.counterParty, leg.party, uint160(leg.counterAmount), leg.counterToken);
        emit SwapExecuted(operationId, leg);
    }
}
