// SPDX-License-Identifier: Apache-2.0

pragma solidity ^0.8.20;

import {IAllowanceTransfer} from "./interfaces/IAllowanceTransfer.sol";

/**
 * @dev Atomic swap between two ERC20 legs, moved through Uniswap Permit2
 * AllowanceTransfer. Each party submits its own view under a shared
 * operationId. The first call records the leg (SwapPrepared); the mirrored
 * call re-checks both Permit2 allowances and crosses both movements in one
 * transaction (SwapExecuted), whichever party went first.
 */
contract Permit2Swap {
    // Permissionless by design: safety comes from Permit2 allowances granted to
    // THIS contract and from the mirror check binding both legs together.
    //  - An allowance towards it is spendable by ANY mirrored pair naming the
    //    approving party, so grant exact, per-swap allowances only.
    //  - The Permit2 expiry limits how long a granted allowance can be used.
    //  - operationId is first-writer-wins: a prepared leg holds the id.

    struct Leg {
        address token;
        address party;
        uint256 amount;
        address counterToken;
        address counterParty;
        uint256 counterAmount;
    }

    /// @notice First leg of a swap recorded, waiting for the counterparty's mirror call
    event SwapPrepared(string indexed operationId, Leg leg);

    /// @notice Both legs matched, tokens exchanged atomically (emitted from the second, executing call)
    event SwapExecuted(string indexed operationId, Leg leg);

    IAllowanceTransfer public immutable permit2;

    mapping(string => Leg) private swaps;

    constructor(address permit2_) {
        require(permit2_ != address(0), "Permit2Swap: permit2 is zero address");
        permit2 = IAllowanceTransfer(permit2_);
    }

    /// @notice Prepare or execute a swap. Caller-relative: `leg` describes what
    /// the submitting party sends and expects back. The preparing side must
    /// already hold an unexpired Permit2 allowance for its sending token; the
    /// executing side's call re-verifies both allowances before moving anything.
    function swap(string calldata operationId, Leg calldata leg) external {
        require(leg.token != address(0) && leg.counterToken != address(0), "Permit2Swap: token is zero address");
        require(leg.party != address(0) && leg.counterParty != address(0), "Permit2Swap: party is zero address");
        require(leg.amount > 0 && leg.counterAmount > 0, "Permit2Swap: amount is zero");
        require(
            leg.amount <= type(uint160).max && leg.counterAmount <= type(uint160).max,
            "Permit2Swap: amount exceeds uint160"
        );

        Leg storage s = swaps[operationId];
        if (s.party == address(0)) {
            require(_hasAllowance(leg.token, leg.party, leg.amount), "Permit2Swap: no allowance for the asset leg");
            swaps[operationId] = leg;
            emit SwapPrepared(operationId, leg);
        } else {
            require(
                s.token == leg.counterToken &&
                s.party == leg.counterParty &&
                s.amount == leg.counterAmount &&
                s.counterToken == leg.token &&
                s.counterParty == leg.party &&
                s.counterAmount == leg.amount,
                "Permit2Swap: legs do not mirror the prepared swap"
            );
            require(_hasAllowance(s.token, s.party, s.amount), "Permit2Swap: no allowance for the asset leg");
            require(_hasAllowance(s.counterToken, s.counterParty, s.counterAmount), "Permit2Swap: no allowance for the settlement leg");
            Leg memory prepared = s;
            delete swaps[operationId];
            permit2.transferFrom(prepared.party, prepared.counterParty, uint160(prepared.amount), prepared.token);
            permit2.transferFrom(prepared.counterParty, prepared.party, uint160(prepared.counterAmount), prepared.counterToken);
            emit SwapExecuted(operationId, leg);
        }
    }

    /// @notice Pending (prepared, not yet executed) swap for the operationId, as stored by the preparing party
    function getSwapInfo(string calldata operationId) external view returns (Leg memory) {
        require(swaps[operationId].party != address(0), "Permit2Swap: swap not found");
        return swaps[operationId];
    }

    /// @notice True while a prepared leg is waiting for its mirror
    function hasPendingSwap(string calldata operationId) external view returns (bool) {
        return swaps[operationId].party != address(0);
    }

    function _hasAllowance(address token, address owner, uint256 amount) private view returns (bool) {
        (uint160 allowed, uint48 expiration, ) = permit2.allowance(owner, token, address(this));
        return allowed >= amount && block.timestamp <= expiration;
    }
}
