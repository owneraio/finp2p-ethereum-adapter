// SPDX-License-Identifier: MIT
// Subset of Uniswap Permit2 IAllowanceTransfer (MIT License, Copyright (c) 2022 Uniswap Labs),
// src/interfaces/IAllowanceTransfer.sol at commit cc56ad0f3439c502c246fc5cfcc3db92bb8b7219:
// https://github.com/Uniswap/permit2/blob/cc56ad0f3439c502c246fc5cfcc3db92bb8b7219/src/interfaces/IAllowanceTransfer.sol
// Only the members used by Permit2Swap and its tests are kept.
pragma solidity ^0.8.20;

interface IAllowanceTransfer {
    error AllowanceExpired(uint256 deadline);

    error InsufficientAllowance(uint256 amount);

    struct PermitDetails {
        address token;
        uint160 amount;
        uint48 expiration;
        uint48 nonce;
    }

    struct PermitSingle {
        PermitDetails details;
        address spender;
        uint256 sigDeadline;
    }

    function allowance(address user, address token, address spender)
        external
        view
        returns (uint160 amount, uint48 expiration, uint48 nonce);

    function approve(address token, address spender, uint160 amount, uint48 expiration) external;

    function permit(address owner, PermitSingle memory permitSingle, bytes calldata signature) external;

    function transferFrom(address from, address to, uint160 amount, address token) external;
}
